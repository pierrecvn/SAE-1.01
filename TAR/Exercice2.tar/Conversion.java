
public class Conversion
{

	public static boolean[] entier2Tab(int valeur, int nbElt)
	{

		boolean[] tab;
		int cpt;
		int nbActuel;

		tab = new boolean[nbElt];

		cpt = 0;
		nbActuel = valeur;
		while (cpt < nbElt && nbActuel > 0)
		{

			tab[cpt] = ((nbActuel % 2) == 1) ? true : false;

			nbActuel = nbActuel / 2;
			cpt++;

		}

		return tab;
	}

	public int tab2Entier(boolean[] tab)
	{
		int ret = 0;

		for (int i = 0; i < tab.length; i++)
			if (tab[i])
				ret += Math.pow(2, i);

		return ret;
	}

	public static String enChaine(boolean[] tab)
	{
		
		String ret = "";

		for (int cpt = 0; cpt < tab.length; cpt++)
			ret += "+---------";

		ret += "+\n";

		for (int i = 0; i < tab.length; i++)
			ret += "|  " + String.format("%5s", tab[i]) + "  ";
		
		ret += "|\n";

		for (int cpt = 0; cpt < tab.length; cpt++)
			ret += "+---------";

		ret += "+\n";

		for (int i = 0; i < tab.length; i++)
			ret += "  " + String.format("%5s", i) + "   ";

		return ret;
	}
}